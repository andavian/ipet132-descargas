@echo off
echo Bloqueando ProfiCAD.exe en el Firewall de Windows...

REM Nombre de la regla de firewall
set ruleName="Bloquear ProfiCAD"

REM Ruta del ejecutable
set exePath="C:\Program Files (x86)\ProfiCAD\ProfiCAD.exe"

REM Crear regla de firewall de salida
netsh advfirewall firewall add rule name=%ruleName% dir=out program=%exePath% action=block

REM Crear regla de firewall de entrada
netsh advfirewall firewall add rule name=%ruleName% dir=in program=%exePath% action=block

echo Regla de firewall creada exitosamente.

echo Gracias a MasterEGA por este script!
pause
